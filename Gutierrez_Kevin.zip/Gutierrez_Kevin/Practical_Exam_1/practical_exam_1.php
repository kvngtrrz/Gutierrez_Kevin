<?php
 //1. Loop
echo '1. Loop <br/><br/>';
echo '---A. While Loop---<br/>';

function whileLoop(){
	//initialization
	$x = 0;
	$sum = 0;
	//loop to 10
	while($x <= 10){
		//getting and checking the remaider to indentify if odd or even
		//if 0 == even else odd
		if($x % 2 == 0){
			//add the value of x if even
			$sum += $x;
		}
		//increment
		$x++;
	}

	echo "Sum of all even numbers: " . $sum;
}

whileLoop();

echo '<br/><br/>---B. Do While Loop---<br/>';
function doWhileLoop(){
	//initialization
	$x = 0;
	//label
	echo 'Odd Numbers: ';
	//do action
	do{
		//getting and checking the remaider to indentify if odd or even
		//if 0 == even else odd
		if($x % 2 != 0){
			//display the number
			echo $x . ' ';
		}

		//increment
		$x++;
	}
	//until value of x == 10
	while($x <= 10);
}

doWhileLoop();

echo '<br/><br/>---C. For Loop---<br/>';
function forLoop(){
	//label
	echo 'Fibonacci: ';
	//initialize first 2 numbers
	$first_num = 0;
	$second_num = 1;
	//loop 10 times
	for($x=0;$x<10;$x++){
		echo $first_num . ' ';
		//add first and second num
		$sum = $first_num + $second_num;
		//set value of first number equal to second number
		$first_num = $second_num;
		//set value of second number to sum of the first previous 1st and 2nd numbers; 
		$second_num = $sum;
	}

}

forLoop();


 //2. Arrays
echo '<br/><br/>2. Arrays <br/><br/>';
echo '---A. Most Occurence---<br/>';

function mostOccurence(){
	//initialization
	$names = ['Marvin', 'Marco', 'Marvin', 'Marco', 'Marco', 'Marvin', 'Christian'];
	$most_occurence = '';
	//will be used to save the most count of occurence
	$most_count = 0;
	/*the process is to first get the distinct names from the first array which will be saved to 2nd array, 
	then do a loop on the 2nd array and compare each name to the first array to count the number of occurence.
	*/
	//get distinct names
	$distinct_names = array_unique($names);
	//loop
	foreach ($distinct_names as $key => $value) {
		$count = 0;
		for($x=0;$x<count($names);$x++){
			if($value == $names[$x]){
				$count += 1;
			}
		}
		//compare new count to most count
		if($count > $most_count){
			//if true then saved the value as the most occurence name and update the # of most occurence
			$most_occurence = $value;
			$most_count = $count;
		}
	}
	echo 'Most Occurence: ' . $most_occurence;
}

mostOccurence();

echo '<br/><br/>---B. Sorting---<br/>';
function sorting(){
	//initialization
	$numbers = [9863, 7127, 2020, 80, 131, 55, 100];
	$total_no = count($numbers);
	//loop for sorting
	for($x=0;$x<$total_no;$x++){
		for($y=0;$y<$total_no;$y++){
			if($numbers[$x] < $numbers[$y]){
				$temp_num = $numbers[$x];
				$numbers[$x] = $numbers[$y];
				$numbers[$y] = $temp_num;
			}
		}
	}
	//loop to display result
	for($x=0;$x<$total_no;$x++){
		//check if value is odd
		if($numbers[$x] % 2 != 0){
			//round off to nearest tens
			$numbers[$x] = round($numbers[$x], -1);
		}
		echo $numbers[$x] . ' ';
	}
}

sorting();

echo '<br/><br/>---C. Not Repetitive---<br/>';

function notRepetitive(){
	//initialization
	$colors = ['red', 'blue', 'black', 'red', 'blue', 'blue', 'red', 'gold'];
	$not_repetitive = '';
	//set initial value to 1
	$least_count = 1;
	//I will use almost the same process on problem A
	
	//get distinct colors
	$distinct_colors = array_unique($colors);
	//loop
	foreach ($distinct_colors as $key => $value) {
		$count = 0;
		for($x=0;$x<count($colors);$x++){
			if($value == $colors[$x]){
				$count += 1;
			}
		}
		//compare new count to least count
		if($count <= $least_count){
			//if true then saved the value as the least occurence color and update the # of least occurence
			$not_repetitive = $not_repetitive . ' ' . $value;
			$least_count = $count;
		}
	}
	echo 'Not Repetitive: ' . $not_repetitive;
}

notRepetitive();
?>