<?php 

echo 'SQL';
echo '<br/><br/>--A. Highest Paid--<br/>';
function highestPaidEmp(){
	//database connection
	$db_conn = mysqli_connect('localhost','root','','sql_exam') or die('Database connection failed.');
	//query to get all employees in descending order of salary
	$query = mysqli_query($db_conn, 'SELECT employees.name FROM employees INNER JOIN salary ON employees.salary_id = salary.id ORDER By salary.salary DESC');
	if(mysqli_num_rows($query) > 0){
		//get results
		$row = mysqli_fetch_array($query);
		echo 'Highest paid employee: ' . $row["name"];
	}
}

highestPaidEmp();

echo '<br/><br/>--B. Hired Employees--<br/>';
function hiredEmp(){
	//database connection
	$db_conn = mysqli_connect('localhost','root','','sql_exam') or die('Database connection failed.');
	//query to get all employees hired from 2017 - 2018
	$query = mysqli_query($db_conn, 'SELECT employees.name FROM employees WHERE YEAR(employees.date_hired) >= 2017 AND YEAR(employees.date_hired) <= 2018');
	if(mysqli_num_rows($query) > 0){
		//get results and loop
		echo 'Hired employees from 2017-2018: ';
		while($row = mysqli_fetch_array($query)){
			echo $row["name"] . ' ';
		}
	}
}

hiredEmp();

echo '<br/><br/>--C. IT Dept 2018--<br/>';
function itDept2018(){
	//database connection
	$db_conn = mysqli_connect('localhost','root','','sql_exam') or die('Database connection failed.');
	//query to get all employees from IT dept and hired 2018 onwards
	$query = mysqli_query($db_conn, 'SELECT employees.name FROM employees INNER JOIN departments ON employees.department_id = departments.id WHERE YEAR(employees.date_hired) >= 2018 AND departments.department = "IT"');
	if(mysqli_num_rows($query) > 0){
		//get results and loop
		echo 'IT dept employees hired 2018 onwards: ';
		while($row = mysqli_fetch_array($query)){
			echo $row["name"] . ' ';
		}
	}
}

itDept2018();
?>