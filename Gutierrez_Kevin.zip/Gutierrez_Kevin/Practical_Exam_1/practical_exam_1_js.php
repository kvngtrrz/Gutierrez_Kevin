<html>
<label>Javascript</label><br/>
<label>--A. Fix the sentence--</label><br/>
<label id="sentence"></label>
<script type="text/javascript">
	
	var sentence = 'TheQuickBrownFoxJumpsOverTheLazyDog.';
	var arr_sentence = [];
	//split the string on capital letter then save to array
	arr_sentence = sentence.split(/(?=[A-Z])/);
	//get lenght of array
	var arr_length = arr_sentence.length;
	var x = 0;
	var new_sentence = '';
	//loop through the array
	for(x=0;x<arr_length;x++){
		//if first word, make first letter capitalize else to lower case
		if(x == 0){
			new_sentence = new_sentence.concat(arr_sentence[x].charAt(0).toUpperCase() + arr_sentence[x].slice(1), ' ');
		}
		else{
			new_sentence = new_sentence.concat(arr_sentence[x].toLowerCase(), ' ');
		}
	}
	//set value of label
	document.getElementById('sentence').innerHTML = new_sentence;
</script>


<label><br/><br/>--B. Contact Form--</label><br/>
Name: <input type="text" name="name" id="name"><br/>
Birth Date: <input type="text" name="bdate" id="bdate"><br/>
Gender: <input type="radio" name="gender" id="male" value="male"> Male
<input type="radio" name="gender" id="female" value="female"> Female <br/>
Know Language: <input type="checkbox" name="knownLanguage" id="English" value="English"> English
<input type="checkbox" name="knownLanguage" id="Japanese" value="Japanese"> Japanese
<input type="checkbox" name="knownLanguage" id="Chinese" value="Chinese"> Chinese
<script type="text/javascript">
	fetch('employees.json')
		.then(function (response){
			return response.json();
		})
		.then(function (data){
			getData(data);
		})
		.catch(function (err){
			console.log('error: ' + err);
		});

	function getData(data){
		data.sort(function(a, b){
			return a.lastName > b.lastName;
		});
		document.getElementById("name").value = data[0].firstName + ' ' + data[0].lastName;
		document.getElementById("bdate").value = data[0].birthday;

		if(data[0].gender.female == true){
			document.getElementById("female").checked = true;
		}
		else{
			document.getElementById("male").checked = true;
		}
		data[0].knownLanguage.forEach(function (language){
			document.getElementById(language).checked = true;
		});
	}
		

</script>
</html>