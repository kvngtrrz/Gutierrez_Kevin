<html>
<body>
	<form method="POST" action="index.php">
		Enter last number: <input type="text" name="input_num">
		<input type="submit" name="check" value="Generate Results">
	</form>
</body>	
</html>

<?php
	if(isset($_POST["check"])){
		//get the input last number
		$last_num = $_POST["input_num"] ;
		//loop	
		for($x=1;$x<=$last_num;$x++){
			//solve each formulas
			$formula1 = sqrt(((5*($x*$x))+4));
			$formula2 = sqrt(((5*($x*$x))-4));
			//check answers if decimal
			if(((is_numeric($formula1) && floor($formula1) != $formula1) != 1) OR ((is_numeric($formula2) && floor($formula2) != $formula2) != 1)) {
				echo $x . " is a Fibonacci Number.<br/>";
			}
			else{
				echo $x . " is a not Fibonacci Number.<br/>";
			}
		}
		
	}
?>