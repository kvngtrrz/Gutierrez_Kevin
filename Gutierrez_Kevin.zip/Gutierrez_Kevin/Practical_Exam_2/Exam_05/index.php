<html>
<body>
	<form method="POST" action="index.php">
		<input type="text" name="input_text">
		<input type="submit" name="check" value="Reverse">
	</form>
</body>	
</html>

<?php
	if(isset($_POST["check"])){
		//get the input text
		$input_text = $_POST["input_text"];
		$input_length = strlen($input_text);
		$input_arr = [];
		//loop to store each letter to an array
		for($x=0;$x<$input_length;$x++){
			$input_arr[$x] = substr($input_text, $x, 1);
		}

		$reverse = '';
		//save the reverse word
		for($x=count($input_arr)-1;$x>=0;$x--){
			$reverse = $reverse . $input_arr[$x];
		}
		//display input and output
		echo 'Input: ' . $input_text . '<br/>';
		echo 'Output: ' . $reverse . '<br/>';
		
	}
?>