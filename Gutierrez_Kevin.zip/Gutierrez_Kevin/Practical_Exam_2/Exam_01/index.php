<html>
<body>
	<form method="POST" action="index.php">
		<input type="text" name="input_text">
		<input type="submit" name="check" value="Check if Palindrome">
	</form>
</body>	
</html>

<?php
	if(isset($_POST["check"])){
		//get the input text, transform it to lower case and remove spaces
		$input_text = str_replace(" ", "", strtolower($_POST["input_text"])) ;
		$input_length = strlen($input_text);
		$input_arr = [];
		//loop to store each letter to an array
		for($x=0;$x<$input_length;$x++){
			$input_arr[$x] = substr($input_text, $x, 1);
		}

		$reverse = '';
		//save the reverse word
		for($x=count($input_arr)-1;$x>=0;$x--){
			$reverse = $reverse . $input_arr[$x];
		}
		//compare the input to the reverse word.
		if($input_text == $reverse){
			echo "Word/Phrase is palindrome";
		}
		else{
			echo "Word/Phrase is not palindrome";	
		}
		
	}
?>