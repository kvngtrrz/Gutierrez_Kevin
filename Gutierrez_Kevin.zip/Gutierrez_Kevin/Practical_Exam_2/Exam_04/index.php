<html>
<body>
	<form method="POST" action="index.php">
		Date 1: <input type="date" name="date_1"><br/>
		Date 2: <input type="date" name="date_2"><br/>
		<input type="submit" name="check" value="Calculate Difference">
	</form>
</body>	
</html>

<?php
	if(isset($_POST["check"])){
		//get the input dates
		$first_date = strtotime($_POST["date_1"]);
		$second_date = strtotime($_POST["date_2"]) ;
		//Format and display dates in 'Y-m-d'
		echo 'First Date: ' . date('Y-m-d',$first_date);
		echo '<br/>Second Date: ' . date('Y-m-d',$second_date);
		//reverse inputs if second date is higher
		if($first_date < $second_date){
			$temp = $first_date;
			$first_date = $second_date;
			$second_date = $temp;
		}
		//get diff between years, months and days
		$diff_year = date('Y', $first_date) - date('Y', $second_date);
		$diff_month = date('m', $first_date) - date('m', $second_date);
		$diff_day = date('d', $first_date) - date('d', $second_date);
		//display output
		echo '<br/>Difference: ' . $diff_year . ' Year/s, ' . $diff_month . 'Month/s, ' . $diff_day . 'Day/s';

	}
?>